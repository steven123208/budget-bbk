import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  AlertCircle, 
  CheckCircle2,
  ArrowUpRight,
  ArrowDownRight,
  Save
} from 'lucide-react';
import { MonthlyBudget, BudgetEntry } from '../types';
import { formatFCFA, calculateTotal, cn } from '../utils';
import { motion } from 'motion/react';

interface RealityFormProps {
  budget: MonthlyBudget;
  onSave: (updatedBudget: MonthlyBudget) => void;
}

export const RealityForm: React.FC<RealityFormProps> = ({ budget, onSave }) => {
  const [localBudget, setLocalBudget] = useState<MonthlyBudget>(budget);

  useEffect(() => {
    setLocalBudget(budget);
  }, [budget]);

  const updateEntry = (category: keyof MonthlyBudget, index: number, field: keyof BudgetEntry, value: any) => {
    const updated = { ...localBudget };
    const list = updated[category] as BudgetEntry[];
    list[index] = { ...list[index], [field]: value };
    setLocalBudget(updated);
  };

  const handleSave = () => {
    onSave({ ...localBudget, validatedReality: true });
  };

  const getAnalysis = (entry: BudgetEntry) => {
    if (!entry.planned) return null;
    const diff = entry.actual - entry.planned;
    const percent = (diff / entry.planned) * 100;
    
    if (percent > 20) {
      return {
        text: `Dépensé ${Math.round(percent)}% de plus en ${entry.label.toLowerCase()}`,
        type: 'error'
      };
    }
    return null;
  };

  const renderSection = (title: string, category: keyof MonthlyBudget, colorClass: string) => {
    const entries = localBudget[category] as BudgetEntry[];
    const totalPlanned = calculateTotal(entries, 'planned');
    const totalActual = calculateTotal(entries, 'actual');
    const diff = totalActual - totalPlanned;
    const isRevenue = category === 'revenues';

    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className={cn("text-lg font-bold flex items-center gap-2", colorClass)}>
            <div className={cn("w-2 h-6 rounded-full", colorClass.replace('text-', 'bg-'))} />
            {title}
          </h3>
          <div className="text-right">
            <div className="text-sm font-bold text-slate-900">
              Réel: {formatFCFA(totalActual)}
            </div>
            <div className={cn("text-[10px] font-medium", diff > 0 ? (isRevenue ? 'text-emerald-600' : 'text-brand-red') : (isRevenue ? 'text-brand-red' : 'text-emerald-600'))}>
              {diff > 0 ? '+' : ''}{formatFCFA(diff)} vs prévu
            </div>
          </div>
        </div>
        <div className="grid gap-4">
          {entries.map((entry, idx) => {
            const analysis = getAnalysis(entry);
            return (
              <div key={entry.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-semibold text-slate-700">{entry.label}</span>
                  <span className="text-xs text-slate-400">Prévu: {formatFCFA(entry.planned)}</span>
                </div>
                <div className="flex gap-3 items-center">
                  <div className="relative flex-1">
                    <input
                      type="number"
                      value={entry.actual || ''}
                      onChange={(e) => updateEntry(category, idx, 'actual', Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-right font-bold focus:ring-2 focus:ring-brand-red/20"
                      placeholder="0"
                    />
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xs text-slate-400">Montant Réel</span>
                  </div>
                </div>
                {analysis && (
                  <div className="mt-3 flex items-center gap-2 text-[11px] font-bold text-brand-red bg-brand-red/5 p-2 rounded-lg">
                    <AlertCircle size={14} />
                    {analysis.text}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const totalPlannedRev = calculateTotal(localBudget.revenues, 'planned');
  const totalActualRev = calculateTotal(localBudget.revenues, 'actual');
  const totalPlannedExp = calculateTotal(localBudget.expenses, 'planned') + calculateTotal(localBudget.bills, 'planned');
  const totalActualExp = calculateTotal(localBudget.expenses, 'actual') + calculateTotal(localBudget.bills, 'actual');
  
  const revRate = totalPlannedRev ? (totalActualRev / totalPlannedRev) * 100 : 0;
  const expRate = totalPlannedExp ? (totalActualExp / totalPlannedExp) * 100 : 0;

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="max-w-4xl mx-auto pb-24"
    >
      <div className="mb-8">
        <h2 className="text-3xl font-black text-slate-900">Réalité</h2>
        <p className="text-slate-500">Saisissez vos revenus et dépenses réels pour comparer.</p>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="card-finance bg-emerald-50 border-emerald-100">
          <div className="text-[10px] uppercase tracking-wider font-bold text-emerald-600 mb-1">Taux Revenus</div>
          <div className="text-2xl font-black text-emerald-700">{Math.round(revRate)}%</div>
          <div className="mt-2 h-1.5 w-full bg-emerald-200 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500" style={{ width: `${Math.min(revRate, 100)}%` }} />
          </div>
        </div>
        <div className="card-finance bg-brand-red/5 border-brand-red/10">
          <div className="text-[10px] uppercase tracking-wider font-bold text-brand-red mb-1">Taux Dépenses</div>
          <div className="text-2xl font-black text-brand-red">{Math.round(expRate)}%</div>
          <div className="mt-2 h-1.5 w-full bg-brand-red/20 rounded-full overflow-hidden">
            <div className="h-full bg-brand-red" style={{ width: `${Math.min(expRate, 100)}%` }} />
          </div>
        </div>
      </div>

      <div className="grid gap-8">
        {renderSection("Revenus Réels", "revenues", "text-emerald-600")}
        {renderSection("Dépenses Variables", "expenses", "text-blue-600")}
        {renderSection("Factures Fixes", "bills", "text-brand-red")}
        {renderSection("Épargne Réalisée", "savings", "text-purple-600")}
        {renderSection("Dettes Remboursées", "debts", "text-orange-600")}
      </div>

      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-full max-w-md px-4 z-50">
        <button 
          onClick={handleSave}
          className="w-full bg-brand-dark hover:bg-black text-white py-4 rounded-2xl font-bold shadow-xl flex items-center justify-center gap-3 transition-all active:scale-95"
        >
          <Save size={24} />
          SAUVEGARDER LA RÉALITÉ
        </button>
      </div>
    </motion.div>
  );
};

import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Save, 
  CheckCircle2, 
  Copy,
  ArrowRight
} from 'lucide-react';
import { MonthlyBudget, BudgetEntry, REVENUE_SOURCES, EXPENSE_CATEGORIES, BILL_CATEGORIES, SAVING_CATEGORIES, DEBT_CATEGORIES } from '../types';
import { formatFCFA, calculateTotal, cn } from '../utils';
import { motion } from 'motion/react';

interface ForecastFormProps {
  budget: MonthlyBudget;
  onSave: (updatedBudget: MonthlyBudget) => void;
  onCopyPrevious: () => void;
}

export const ForecastForm: React.FC<ForecastFormProps> = ({ budget, onSave, onCopyPrevious }) => {
  const [localBudget, setLocalBudget] = useState<MonthlyBudget>(budget);

  useEffect(() => {
    setLocalBudget(budget);
  }, [budget]);

  const updateEntry = (category: keyof MonthlyBudget, index: number, field: keyof BudgetEntry, value: any) => {
    const updated = { ...localBudget };
    const list = updated[category] as BudgetEntry[];
    list[index] = { ...list[index], [field]: value };
    setLocalBudget(updated);
  };

  const handleSave = () => {
    onSave({ ...localBudget, validatedForecast: true });
  };

  const renderSection = (title: string, category: keyof MonthlyBudget, defaultLabels: string[], colorClass: string) => {
    const entries = localBudget[category] as BudgetEntry[];
    
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className={cn("text-lg font-bold flex items-center gap-2", colorClass)}>
            <div className={cn("w-2 h-6 rounded-full", colorClass.replace('text-', 'bg-'))} />
            {title}
          </h3>
          <span className="text-sm font-medium text-slate-500">
            Total: {formatFCFA(calculateTotal(entries, 'planned'))}
          </span>
        </div>
        <div className="grid gap-3">
          {entries.map((entry, idx) => (
            <div key={entry.id} className="flex gap-3 items-center bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
              <input
                type="text"
                value={entry.label}
                onChange={(e) => updateEntry(category, idx, 'label', e.target.value)}
                className="flex-1 bg-transparent font-medium focus:outline-none"
                placeholder="Libellé"
              />
              <div className="relative w-32 md:w-48">
                <input
                  type="number"
                  value={entry.planned || ''}
                  onChange={(e) => updateEntry(category, idx, 'planned', Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-right focus:ring-2 focus:ring-brand-red/20"
                  placeholder="0"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 pointer-events-none">F</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto pb-24"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-black text-slate-900">Prévisions</h2>
          <p className="text-slate-500">Définissez vos objectifs financiers pour ce mois.</p>
        </div>
        <button 
          onClick={onCopyPrevious}
          className="flex items-center gap-2 text-sm font-semibold text-brand-red hover:bg-brand-red/5 px-4 py-2 rounded-lg transition-colors"
        >
          <Copy size={16} />
          Copier du mois précédent
        </button>
      </div>

      <div className="grid gap-8">
        {renderSection("Sources de Revenus", "revenues", REVENUE_SOURCES, "text-emerald-600")}
        {renderSection("Dépenses Variables", "expenses", EXPENSE_CATEGORIES, "text-blue-600")}
        {renderSection("Factures Fixes", "bills", BILL_CATEGORIES, "text-brand-red")}
        {renderSection("Épargne & Projets", "savings", SAVING_CATEGORIES, "text-purple-600")}
        {renderSection("Dettes & Urgences", "debts", DEBT_CATEGORIES, "text-orange-600")}
      </div>

      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-full max-w-md px-4 z-50">
        <button 
          onClick={handleSave}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-2xl font-bold shadow-xl shadow-emerald-200 flex items-center justify-center gap-3 transition-all active:scale-95"
        >
          <CheckCircle2 size={24} />
          VALIDER LES PRÉVISIONS
        </button>
      </div>
    </motion.div>
  );
};

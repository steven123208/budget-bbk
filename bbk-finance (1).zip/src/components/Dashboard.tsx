import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  LineChart,
  Line,
  PieChart,
  Pie
} from 'recharts';
import { MonthlyBudget } from '../types';
import { formatFCFA, calculateTotal, getMonthName } from '../utils';
import { TrendingUp, TrendingDown, Target, Wallet, ShieldCheck, AlertTriangle, XCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface DashboardProps {
  budgets: MonthlyBudget[];
  currentMonth: MonthlyBudget;
}

export const Dashboard: React.FC<DashboardProps> = ({ budgets, currentMonth }) => {
  const sortedBudgets = [...budgets].sort((a, b) => a.id.localeCompare(b.id));

  const performanceData = sortedBudgets.map(b => {
    const rev = calculateTotal(b.revenues, 'actual');
    const exp = calculateTotal(b.expenses, 'actual') + calculateTotal(b.bills, 'actual');
    const plannedRev = calculateTotal(b.revenues, 'planned');
    
    let status = 'neutral';
    if (exp < rev * 0.7 && rev > plannedRev * 0.9) status = 'success';
    else if (exp > rev * 0.85) status = 'danger';
    else status = 'warning';

    return {
      name: getMonthName(b.month).substring(0, 3),
      revenues: rev,
      expenses: exp,
      status
    };
  });

  const savingsData = sortedBudgets.reduce((acc: any[], b) => {
    const monthlySaving = calculateTotal(b.savings, 'actual');
    const prevTotal = acc.length > 0 ? acc[acc.length - 1].total : 0;
    acc.push({
      name: getMonthName(b.month).substring(0, 3),
      total: prevTotal + monthlySaving
    });
    return acc;
  }, []);

  const currentExpData = [
    { name: 'Variables', value: calculateTotal(currentMonth.expenses, 'actual'), color: '#3B82F6' },
    { name: 'Fixes', value: calculateTotal(currentMonth.bills, 'actual'), color: '#E11D48' },
    { name: 'Épargne', value: calculateTotal(currentMonth.savings, 'actual'), color: '#9333EA' },
    { name: 'Dettes', value: calculateTotal(currentMonth.debts, 'actual'), color: '#EA580C' },
  ].filter(d => d.value > 0);

  const totalRev = calculateTotal(currentMonth.revenues, 'actual');
  const totalExp = calculateTotal(currentMonth.expenses, 'actual') + calculateTotal(currentMonth.bills, 'actual');
  const expRatio = totalRev ? (totalExp / totalRev) * 100 : 0;

  const getStatusInfo = () => {
    if (expRatio < 70) return { icon: ShieldCheck, color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'Objectif Atteint', desc: 'Excellente gestion ! Vos dépenses sont sous contrôle.' };
    if (expRatio < 85) return { icon: AlertTriangle, color: 'text-orange-600', bg: 'bg-orange-50', label: 'À Surveiller', desc: 'Attention, vous approchez de la limite de sécurité.' };
    return { icon: XCircle, color: 'text-brand-red', bg: 'bg-red-50', label: 'Dépassement', desc: 'Vos dépenses dépassent 85% de vos revenus.' };
  };

  const status = getStatusInfo();

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-6xl mx-auto pb-12"
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className={cn("md:col-span-2 card-finance flex items-center gap-6", status.bg)}>
          <div className={cn("p-4 rounded-2xl bg-white shadow-sm", status.color)}>
            <status.icon size={48} />
          </div>
          <div>
            <h3 className={cn("text-2xl font-black", status.color)}>{status.label}</h3>
            <p className="text-slate-600 font-medium">{status.desc}</p>
          </div>
        </div>
        <div className="card-finance bg-brand-dark text-white flex flex-col justify-center">
          <div className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">Écart Net</div>
          <div className="text-3xl font-black">{formatFCFA(totalRev - totalExp)}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="card-finance">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <TrendingUp size={20} className="text-emerald-500" />
            Performance Mensuelle
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 600 }} />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  formatter={(value: number) => formatFCFA(value)}
                />
                <Bar dataKey="revenues" radius={[4, 4, 0, 0]}>
                  {performanceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.status === 'success' ? '#10B981' : entry.status === 'danger' ? '#E11D48' : '#F59E0B'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card-finance">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <Wallet size={20} className="text-purple-500" />
            Évolution Épargne
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={savingsData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 600 }} />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  formatter={(value: number) => formatFCFA(value)}
                />
                <Line type="monotone" dataKey="total" stroke="#9333EA" strokeWidth={4} dot={{ r: 6, fill: '#9333EA', strokeWidth: 2, stroke: '#fff' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card-finance">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <Target size={20} className="text-blue-500" />
            Répartition Dépenses
          </h3>
          <div className="h-64 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={currentExpData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {currentExpData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => formatFCFA(value)} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-col gap-2 ml-4">
              {currentExpData.map((d, i) => (
                <div key={i} className="flex items-center gap-2 text-xs font-bold">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }} />
                  <span className="text-slate-500">{d.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="card-finance bg-slate-50 border-none">
          <h3 className="text-lg font-bold mb-4">Conseils BBK FINANCE</h3>
          <div className="space-y-4">
            {expRatio > 85 && (
              <div className="p-4 bg-white rounded-xl border-l-4 border-brand-red shadow-sm">
                <p className="text-sm font-medium text-slate-700">
                  ⚠️ Vos dépenses sont trop élevées ce mois-ci ({Math.round(expRatio)}%). Essayez de réduire les sorties ou la restauration street food.
                </p>
              </div>
            )}
            {calculateTotal(currentMonth.savings, 'actual') < calculateTotal(currentMonth.savings, 'planned') && (
              <div className="p-4 bg-white rounded-xl border-l-4 border-purple-500 shadow-sm">
                <p className="text-sm font-medium text-slate-700">
                  💡 Discipline épargne : Vous n'avez pas atteint votre objectif d'épargne. Priorisez vos projets BBK Services le mois prochain.
                </p>
              </div>
            )}
            <div className="p-4 bg-white rounded-xl border-l-4 border-emerald-500 shadow-sm">
              <p className="text-sm font-medium text-slate-700">
                🚀 Astuce : Investissez vos surplus de revenus freelance dans votre fonds d'urgence pour une meilleure sérénité.
              </p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

import { cn } from '../utils';

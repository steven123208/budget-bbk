import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Calendar, 
  Target, 
  History, 
  Moon, 
  Sun, 
  Wallet,
  Download,
  FileSpreadsheet,
  FileText,
  ChevronLeft,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { MonthlyBudget, TabType, REVENUE_SOURCES, EXPENSE_CATEGORIES, BILL_CATEGORIES, SAVING_CATEGORIES, DEBT_CATEGORIES } from './types';
import { initDB, saveBudget, getBudget, getAllBudgets } from './services/db';
import { ForecastForm } from './components/ForecastForm';
import { RealityForm } from './components/RealityForm';
import { Dashboard } from './components/Dashboard';
import { formatFCFA, getMonthName, cn } from './utils';
import { motion, AnimatePresence } from 'motion/react';
import { jsPDF } from 'jspdf';
import * as XLSX from 'xlsx';

const generateEmptyBudget = (month: number, year: number): MonthlyBudget => ({
  id: `${year}-${String(month).padStart(2, '0')}`,
  month,
  year,
  revenues: REVENUE_SOURCES.map(label => ({ id: Math.random().toString(36).substr(2, 9), label, planned: 0, actual: 0, category: 'revenue' })),
  expenses: EXPENSE_CATEGORIES.map(label => ({ id: Math.random().toString(36).substr(2, 9), label, planned: 0, actual: 0, category: 'expense' })),
  bills: BILL_CATEGORIES.map(label => ({ id: Math.random().toString(36).substr(2, 9), label, planned: 0, actual: 0, category: 'bill' })),
  savings: SAVING_CATEGORIES.map(label => ({ id: Math.random().toString(36).substr(2, 9), label, planned: 0, actual: 0, category: 'saving' })),
  debts: DEBT_CATEGORIES.map(label => ({ id: Math.random().toString(36).substr(2, 9), label, planned: 0, actual: 0, category: 'debt' })),
  validatedForecast: false,
  validatedReality: false,
});

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('forecast');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [currentBudget, setCurrentBudget] = useState<MonthlyBudget | null>(null);
  const [allBudgets, setAllBudgets] = useState<MonthlyBudget[]>([]);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      const month = currentDate.getMonth() + 1;
      const year = currentDate.getFullYear();
      const id = `${year}-${String(month).padStart(2, '0')}`;
      
      let budget = await getBudget(id);
      if (!budget) {
        budget = generateEmptyBudget(month, year);
        await saveBudget(budget);
      }
      setCurrentBudget(budget);

      const all = await getAllBudgets();
      setAllBudgets(all);
      
      if (all.length === 1 && !all[0].validatedForecast) {
        setShowOnboarding(true);
      }
    };
    loadData();
  }, [currentDate]);

  const handleSaveBudget = async (updated: MonthlyBudget) => {
    await saveBudget(updated);
    setCurrentBudget(updated);
    const all = await getAllBudgets();
    setAllBudgets(all);
  };

  const handleCopyPrevious = async () => {
    const prevDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1);
    const prevId = `${prevDate.getFullYear()}-${String(prevDate.getMonth() + 1).padStart(2, '0')}`;
    const prevBudget = await getBudget(prevId);
    
    if (prevBudget && currentBudget) {
      const updated = {
        ...currentBudget,
        revenues: currentBudget.revenues.map((r, i) => ({ ...r, planned: prevBudget.revenues[i]?.planned || 0 })),
        expenses: currentBudget.expenses.map((e, i) => ({ ...e, planned: prevBudget.expenses[i]?.planned || 0 })),
        bills: currentBudget.bills.map((b, i) => ({ ...b, planned: prevBudget.bills[i]?.planned || 0 })),
        savings: currentBudget.savings.map((s, i) => ({ ...s, planned: prevBudget.savings[i]?.planned || 0 })),
        debts: currentBudget.debts.map((d, i) => ({ ...d, planned: prevBudget.debts[i]?.planned || 0 })),
      };
      handleSaveBudget(updated);
    }
  };

  const exportPDF = () => {
    if (!currentBudget) return;
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text(`BBK FINANCE - Budget ${getMonthName(currentBudget.month)} ${currentBudget.year}`, 20, 20);
    doc.setFontSize(12);
    doc.text(`Généré le: ${new Date().toLocaleDateString('fr-FR')}`, 20, 30);
    
    let y = 50;
    const addSection = (title: string, entries: any[]) => {
      doc.setFont("helvetica", "bold");
      doc.text(title, 20, y);
      y += 10;
      doc.setFont("helvetica", "normal");
      entries.forEach(e => {
        doc.text(`${e.label}: Prévu ${formatFCFA(e.planned)} | Réel ${formatFCFA(e.actual)}`, 30, y);
        y += 8;
      });
      y += 5;
    };

    addSection("Revenus", currentBudget.revenues);
    addSection("Dépenses", currentBudget.expenses);
    addSection("Factures", currentBudget.bills);
    addSection("Épargne", currentBudget.savings);
    
    doc.save(`BBK_Budget_${currentBudget.id}.pdf`);
  };

  const exportExcel = () => {
    if (!currentBudget) return;
    const data = [
      ['Catégorie', 'Libellé', 'Prévu (FCFA)', 'Réel (FCFA)'],
      ...currentBudget.revenues.map(e => ['Revenu', e.label, e.planned, e.actual]),
      ...currentBudget.expenses.map(e => ['Dépense', e.label, e.planned, e.actual]),
      ...currentBudget.bills.map(e => ['Facture', e.label, e.planned, e.actual]),
      ...currentBudget.savings.map(e => ['Épargne', e.label, e.planned, e.actual]),
    ];
    const ws = XLSX.utils.aoa_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Budget");
    XLSX.writeFile(wb, `BBK_Budget_${currentBudget.id}.xlsx`);
  };

  const changeMonth = (offset: number) => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + offset, 1));
  };

  if (!currentBudget) return null;

  return (
    <div className={cn("min-h-screen", isDarkMode ? "bg-slate-950 text-white" : "bg-slate-50 text-slate-900")}>
      {/* Header */}
      <header className="bg-brand-dark text-white sticky top-0 z-40 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-brand-red rounded-xl flex items-center justify-center shadow-lg shadow-brand-red/20">
              <Wallet className="text-white" size={24} />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tighter">BBK FINANCE</h1>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Cotonou, Bénin</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center bg-white/10 rounded-xl p-1">
              <button onClick={() => changeMonth(-1)} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                <ChevronLeft size={20} />
              </button>
              <span className="px-4 font-bold text-sm min-w-[120px] text-center">
                {getMonthName(currentBudget.month)} {currentBudget.year}
              </span>
              <button onClick={() => changeMonth(1)} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                <ChevronRight size={20} />
              </button>
            </div>
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2.5 bg-white/10 rounded-xl hover:bg-white/20 transition-colors"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar Navigation */}
          <nav className="md:w-64 flex-shrink-0">
            <div className="sticky top-28 space-y-2">
              <NavButton 
                active={activeTab === 'forecast'} 
                onClick={() => setActiveTab('forecast')}
                icon={Target}
                label="Prévisions"
                badge={currentBudget.validatedForecast ? "✓" : undefined}
              />
              <NavButton 
                active={activeTab === 'reality'} 
                onClick={() => setActiveTab('reality')}
                icon={Calendar}
                label="Réalité"
                badge={currentBudget.validatedReality ? "✓" : undefined}
              />
              <NavButton 
                active={activeTab === 'dashboard'} 
                onClick={() => setActiveTab('dashboard')}
                icon={LayoutDashboard}
                label="Analyses"
              />
              
              <div className="pt-8 space-y-4">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-4">Exportation</div>
                <button onClick={exportPDF} className="w-full flex items-center gap-3 px-4 py-3 text-sm font-bold text-slate-500 hover:text-brand-red hover:bg-brand-red/5 rounded-xl transition-all">
                  <FileText size={18} /> PDF du mois
                </button>
                <button onClick={exportExcel} className="w-full flex items-center gap-3 px-4 py-3 text-sm font-bold text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-all">
                  <FileSpreadsheet size={18} /> Excel du mois
                </button>
              </div>
            </div>
          </nav>

          {/* Content Area */}
          <div className="flex-1 min-w-0">
            <AnimatePresence mode="wait">
              {activeTab === 'forecast' && (
                <ForecastForm 
                  key="forecast"
                  budget={currentBudget} 
                  onSave={handleSaveBudget} 
                  onCopyPrevious={handleCopyPrevious}
                />
              )}
              {activeTab === 'reality' && (
                <RealityForm 
                  key="reality"
                  budget={currentBudget} 
                  onSave={handleSaveBudget} 
                />
              )}
              {activeTab === 'dashboard' && (
                <Dashboard 
                  key="dashboard"
                  budgets={allBudgets} 
                  currentMonth={currentBudget} 
                />
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Onboarding Modal */}
      <AnimatePresence>
        {showOnboarding && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl text-center"
            >
              <div className="w-20 h-20 bg-brand-red/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Sparkles className="text-brand-red" size={40} />
              </div>
              <h2 className="text-2xl font-black mb-2">Bienvenue sur BBK FINANCE</h2>
              <p className="text-slate-600 mb-8 font-medium">
                Prêt à prendre le contrôle de vos finances ? Commencez par définir vos prévisions pour ce mois de {getMonthName(currentBudget.month)}.
              </p>
              <button 
                onClick={() => setShowOnboarding(false)}
                className="w-full bg-brand-dark text-white py-4 rounded-2xl font-bold hover:bg-black transition-all"
              >
                C'EST PARTI !
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function NavButton({ active, onClick, icon: Icon, label, badge }: any) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center justify-between px-4 py-4 rounded-2xl font-bold transition-all group",
        active 
          ? "bg-brand-red text-white shadow-lg shadow-brand-red/20 scale-[1.02]" 
          : "text-slate-500 hover:bg-white hover:text-slate-900"
      )}
    >
      <div className="flex items-center gap-3">
        <Icon size={20} className={cn(active ? "text-white" : "text-slate-400 group-hover:text-brand-red")} />
        {label}
      </div>
      {badge && <span className={cn("text-xs px-2 py-0.5 rounded-full", active ? "bg-white/20" : "bg-emerald-100 text-emerald-600")}>{badge}</span>}
    </button>
  );
}

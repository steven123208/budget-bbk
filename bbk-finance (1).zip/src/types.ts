import { Type } from "@google/genai";

export interface BudgetEntry {
  id: string;
  label: string;
  planned: number;
  actual: number;
  category: string;
}

export interface MonthlyBudget {
  id: string; // YYYY-MM
  month: number;
  year: number;
  revenues: BudgetEntry[];
  expenses: BudgetEntry[];
  bills: BudgetEntry[];
  savings: BudgetEntry[];
  debts: BudgetEntry[];
  validatedForecast: boolean;
  validatedReality: boolean;
}

export type TabType = 'forecast' | 'reality' | 'dashboard' | 'history';

export const REVENUE_SOURCES = [
  "Salaire principal (8h-19h)",
  "Commerce de côté",
  "Société BBK Services",
  "Salaire freelance"
];

export const EXPENSE_CATEGORIES = [
  "Marché", "Restauration street food", "Entretien chambre", "Santé/pharmacie", "Beauté/coiffure",
  "Essence moto", "Entretien moto", "Taxis/bus", "Cuisine maison", "Petit-déjeuner",
  "Cadeaux famille", "Loisirs/sorties", "Vêtements", "Déguisements", "Chaussures"
];

export const BILL_CATEGORIES = [
  "Loyer", "Électricité", "Internet (5000F)", "Eau"
];

export const SAVING_CATEGORIES = [
  "Fonds d'urgence", "Tontine", "Projets BBK Services", "Voyage/plaisir", "Études/formation"
];

export const DEBT_CATEGORIES = [
  "BBK Services", "Urgence"
];

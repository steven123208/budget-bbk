import React from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const formatFCFA = (amount: number) => {
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'XOF',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount).replace('XOF', 'FCFA');
};

export const getMonthName = (month: number) => {
  return new Intl.DateTimeFormat('fr-FR', { month: 'long' }).format(new Date(2000, month - 1));
};

export const calculateTotal = (entries: { planned: number; actual: number }[], type: 'planned' | 'actual') => {
  return entries.reduce((sum, entry) => sum + (entry[type] || 0), 0);
};

import { openDB, IDBPDatabase } from 'idb';
import { MonthlyBudget } from '../types';

const DB_NAME = 'bbk_finance_db';
const STORE_NAME = 'budgets';
const VERSION = 1;

export const initDB = async (): Promise<IDBPDatabase> => {
  return openDB(DB_NAME, VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    },
  });
};

export const saveBudget = async (budget: MonthlyBudget) => {
  const db = await initDB();
  await db.put(STORE_NAME, budget);
};

export const getBudget = async (id: string): Promise<MonthlyBudget | undefined> => {
  const db = await initDB();
  return db.get(STORE_NAME, id);
};

export const getAllBudgets = async (): Promise<MonthlyBudget[]> => {
  const db = await initDB();
  return db.getAll(STORE_NAME);
};

export const deleteBudget = async (id: string) => {
  const db = await initDB();
  await db.delete(STORE_NAME, id);
};
